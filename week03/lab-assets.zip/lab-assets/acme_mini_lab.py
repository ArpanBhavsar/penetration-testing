#!/usr/bin/env python3
"""acme_mini_lab.py - Week 3 fallback practice target (Penetration Testing, Focus College).

Starts a few harmless fake services on 127.0.0.1 ONLY (your own computer), so you can
practise Nmap service detection and banner reading when your Metasploitable 2 VM is
not available. Nothing listens on a real network interface.

  python3 acme_mini_lab.py            # runs until Ctrl+C
  nmap -sT -sV -p 2121,2525,8080 127.0.0.1

Ports (all on 127.0.0.1):
  2121  FTP-style banner   (220 acme-legacy FTP service ready)
  2525  SMTP-style dialogue (EHLO, VRFY, QUIT; VRFY answers 252 = cannot verify)
  8080  HTTP server         (Acme "staff portal" page with a Server header)
"""
import socketserver, threading, http.server, sys

HOST = "127.0.0.1"

class FTP(socketserver.StreamRequestHandler):
    def handle(self):
        self.wfile.write(b"220 (vsFTPd 3.0.3)\r\n")
        for line in self.rfile:
            cmd = line.decode(errors="ignore").strip().upper()
            if cmd.startswith("USER"):
                self.wfile.write(b"331 Please specify the password.\r\n")
            elif cmd.startswith("PASS"):
                self.wfile.write(b"530 Login incorrect.\r\n")
            elif cmd.startswith("QUIT"):
                self.wfile.write(b"221 Goodbye.\r\n"); return
            else:
                self.wfile.write(b"530 Please login with USER and PASS.\r\n")

class SMTP(socketserver.StreamRequestHandler):
    def handle(self):
        self.wfile.write(b"220 mail.acme-lab.example ESMTP Postfix (Ubuntu)\r\n")
        for line in self.rfile:
            cmd = line.decode(errors="ignore").strip()
            up = cmd.upper()
            if up.startswith(("EHLO", "HELO")):
                self.wfile.write(b"250-mail.acme-lab.example\r\n250-PIPELINING\r\n250-SIZE 10240000\r\n250-VRFY\r\n250-ETRN\r\n250-8BITMIME\r\n250 DSN\r\n")
            elif up.startswith("VRFY"):
                self.wfile.write(b"252 2.0.0 Cannot VRFY user, but will accept message and attempt delivery\r\n")
            elif up.startswith("QUIT"):
                self.wfile.write(b"221 2.0.0 Bye\r\n"); return
            elif up.startswith("HELP"):
                self.wfile.write(b"214 2.0.0 Commands: EHLO HELO VRFY QUIT HELP\r\n")
            else:
                self.wfile.write(b"502 5.5.2 Error: command not recognized\r\n")

PAGE = b"""<!doctype html><html><head><title>Acme Corp Staff Portal (lab)</title></head>
<body><h1>Acme Corp Staff Portal</h1><p>Training target for Focus College Penetration Testing, Week 3.</p>
<!-- build: portal-2.4.1 --></body></html>"""

class Web(http.server.BaseHTTPRequestHandler):
    server_version = "Apache/2.4.58"
    sys_version = "(Ubuntu)"
    def do_GET(self):
        if self.path == "/robots.txt":
            body = b"User-agent: *\nDisallow: /backup/\n"
            ctype = "text/plain"
        else:
            body, ctype = PAGE, "text/html"
        self.send_response(200); self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
    def do_HEAD(self):
        self.send_response(200); self.send_header("Content-Type", "text/html"); self.end_headers()
    def log_message(self, *a):
        pass

class TS(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

def main():
    servers = [TS((HOST, 2121), FTP), TS((HOST, 2525), SMTP), http.server.ThreadingHTTPServer((HOST, 8080), Web)]
    for s in servers:
        threading.Thread(target=s.serve_forever, daemon=True).start()
    print("Acme mini lab listening on 127.0.0.1: 2121 (FTP), 2525 (SMTP), 8080 (HTTP). Ctrl+C to stop.")
    try:
        threading.Event().wait()
    except KeyboardInterrupt:
        print("\nStopped."); sys.exit(0)

if __name__ == "__main__":
    main()
