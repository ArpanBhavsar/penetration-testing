#!/usr/bin/env python3
"""nmap_to_findings.py - Week 3 helper (Penetration Testing, Focus College).

Turns an Nmap XML file (-oX or -oA) into a report-ready inventory table for
Assignment 1 and Project Phase 2a. Standard library only.

  python3 nmap_to_findings.py sample-output/mini-lab-sV.xml
  python3 nmap_to_findings.py scans/acme-legacy-sV.xml --csv inventory.csv

Each open port becomes one row: host, port/proto, service, product + version,
and a "next step" hint. Confidence is "High" when Nmap reports a version
(service fingerprint matched) and "Verify" when it only guessed from the port.
"""
import argparse, csv, sys
import xml.etree.ElementTree as ET

HINTS = {
    "ftp": "Check anonymous login with ftp-anon (safe); note version for Week 4.",
    "ssh": "Record version; no brute force (not in RoE).",
    "telnet": "Cleartext admin protocol: report as finding; do not log in.",
    "smtp": "Run smtp-commands; VRFY/EXPN only if RoE allows user enumeration.",
    "domain": "Try reverse lookups; AXFR only against the authorized lab DNS.",
    "http": "Run http-title / http-headers; hand the URL to Week 7 web testing.",
    "netbios-ssn": "Enumerate shares with smb-enum-shares or enum4linux-ng (lab only).",
    "microsoft-ds": "Enumerate shares with smb-enum-shares or enum4linux-ng (lab only).",
    "snmp": "Try snmp-info / community 'public' only on lab gear.",
    "mysql": "Record version; database access is out of scope for Phase 2a.",
}

def rows_from(path):
    root = ET.parse(path).getroot()
    out = []
    for host in root.findall("host"):
        if host.find("status").get("state") != "up":
            continue
        addr = host.find("address").get("addr")
        hn = host.find("hostnames/hostname")
        name = hn.get("name") if hn is not None else ""
        for p in host.findall("ports/port"):
            st = p.find("state").get("state")
            if st != "open":
                continue
            svc = p.find("service")
            sname = svc.get("name", "unknown") if svc is not None else "unknown"
            prod = " ".join(x for x in [svc.get("product", ""), svc.get("version", ""), svc.get("extrainfo", "")] if x) if svc is not None else ""
            conf = "High" if (svc is not None and svc.get("method") == "probed" and prod) else "Verify"
            out.append({"host": addr, "hostname": name, "port": f"{p.get('portid')}/{p.get('protocol')}",
                        "service": sname, "version": prod or "(not identified)", "confidence": conf,
                        "next_step": HINTS.get(sname, "Identify the service manually (nc / banner) before reporting.")})
    return root, out

def main(argv=None):
    ap = argparse.ArgumentParser(description="Nmap XML -> findings inventory")
    ap.add_argument("xml"); ap.add_argument("--csv", help="also write CSV here")
    a = ap.parse_args(argv)
    root, rows = rows_from(a.xml)
    print(f"Source: {a.xml}")
    print(f"Command: {root.get('args')}")
    print(f"Scanner: Nmap {root.get('version')}  started: {root.get('startstr')}")
    print()
    print("| Host | Port | Service | Version | Confidence | Next step |")
    print("|---|---|---|---|---|---|")
    for r in rows:
        print(f"| {r['host']} | {r['port']} | {r['service']} | {r['version']} | {r['confidence']} | {r['next_step']} |")
    print()
    print(f"{len(rows)} open port(s) on {len({r['host'] for r in rows})} host(s).")
    if a.csv:
        with open(a.csv, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()) if rows else ["host"]); w.writeheader(); w.writerows(rows)
        print(f"CSV written to {a.csv}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
