# Acme Corp — passive recon artifacts (FICTIONAL, for Week 3 lab Part 1)
All values are invented teaching data using reserved documentation names (.example) and
RFC 5737 addresses. Do NOT look these up against real registries or scan them.

## A. RDAP / WHOIS excerpts (simulated)
| Object | Registrant / org | Notes |
|---|---|---|
| acme-corp.example | Acme Corp, Surrey BC | Registrar: Example Registrar Inc. Created 2014-03-02. NS: ns1.acme-corp.example, ns2.acme-corp.example |
| 203.0.113.0/25 | Acme Corp (ACME-NET-1) | Allocated by Coast ISP; Acme is the customer of record |
| 203.0.113.128/25 | Coast ISP (COAST-POOL-7) | Shared ISP pool — NOT Acme |
| shop-cdn.example | Amazon CloudFront (AWS) | Acme marketing site hosted in AWS |
| help.example | HelpDeskly SaaS Ltd | Vendor-hosted help desk (vendor permission pending) |

## B. DNS records (simulated `dig` answers)
```
acme-corp.example.        3600 IN A     203.0.113.10
acme-corp.example.        3600 IN MX 10 mail.acme-corp.example.
mail.acme-corp.example.   3600 IN A     203.0.113.25
acme-corp.example.        3600 IN TXT   "v=spf1 ip4:203.0.113.0/25 include:spf.helpdeskly.example -all"
vpn.acme-corp.example.    3600 IN A     203.0.113.40
www.acme-corp.example.    3600 IN CNAME shop-cdn.example.
```

## C. Certificate transparency (simulated crt.sh results for %.acme-corp.example)
| Logged name | First seen | Issuer |
|---|---|---|
| www.acme-corp.example | 2025-11-02 | Let's Encrypt R11 |
| vpn.acme-corp.example | 2026-01-14 | Let's Encrypt R11 |
| staging.acme-corp.example | 2026-08-30 | Let's Encrypt R10 |
| dev-api.acme-corp.example | 2026-09-12 | Let's Encrypt R10 |
| help.acme-corp.example (CNAME to help.example) | 2024-06-01 | Sectigo |

## D. People and job-ad clues (simulated)
- Careers page: "Junior SysAdmin — experience with Ubuntu, Postfix, Samba file shares and Cisco SNMP monitoring."
- Leadership page: Jordan Lee (CIO), Sam Okonkwo (Systems Administrator).
- Press release signature: jordan.lee@acme-corp.example  → likely pattern first.last@acme-corp.example

## E. Archive / robots (simulated)
- Wayback snapshot 2023-05: /old-portal/ login page (now 404).
- robots.txt: `Disallow: /backup/`
