#!/usr/bin/env python3
"""scope_guard.py — Week 2 helper, extended for Week 3 (Penetration Testing, Focus College).

Refuse to proceed when a proposed target is outside the approved CIDR ranges
or appears on the exclusion list. Reuse this before Nmap in Week 3.

Usage:
  python3 scope_guard.py targets.txt
  python3 scope_guard.py targets.txt --emit nmap-targets.txt   # Week 3: write ALLOWED lines for nmap -iL
  python3 scope_guard.py --demo
  python3 scope_guard.py targets.txt --add-scope 192.168.110.0/24 --exclude 192.168.110.1 --emit nmap-targets.txt
      # Week 3 (VMware): approve YOUR host-only subnet and exclude your host's own adapter IP.
      # --add-scope and --exclude may be repeated. Only ever add an isolated host-only lab subnet.

The targets file contains one IPv4 address or host label per line.
Lines starting with # are comments.
"""
from __future__ import annotations

import argparse
import ipaddress
import sys
from pathlib import Path

# Acme Project Phase 1 approved ranges (lab + documentation examples)
IN_SCOPE = [
    ipaddress.ip_network("192.168.56.0/24"),  # course host-only lab
    ipaddress.ip_network("203.0.113.0/25"),   # Acme public half (docs range; never scanned live)
    ipaddress.ip_network("127.0.0.0/8"),      # Week 3: your own machine (acme_mini_lab.py)
]

# Week 3: hostnames whose owners explicitly permit light practice scanning
ALLOWED_LABELS = {
    "scanme.nmap.org",       # Nmap project's practice host: light scans only, a few times a day
    "localhost",
}

# Always refuse these even if they fall inside a wide CIDR
EXCLUSIONS = {
    ipaddress.ip_address("192.168.56.1"),     # VirtualBox host gateway (your laptop)
    ipaddress.ip_address("203.0.113.1"),      # reserved example gateway
}

# Labels that are never in scope for Phase 1 without a change order
BLOCKED_LABELS = {
    "help.example",          # SaaS help desk — vendor permission required
    "college.lms.example",   # college systems
}


def classify(token: str) -> tuple[str, str]:
    token = token.strip()
    if not token or token.startswith("#"):
        return "skip", "comment or empty"
    lower = token.lower()
    if lower in BLOCKED_LABELS:
        return "BLOCK", f"label '{token}' is excluded (third-party or college)"
    if lower in ALLOWED_LABELS:
        return "ALLOW", f"label '{token}' is an explicitly permitted practice target"
    try:
        ip = ipaddress.ip_address(token)
    except ValueError:
        return "BLOCK", f"'{token}' is not a bare IPv4 address; resolve and re-check"
    if ip in EXCLUSIONS:
        return "BLOCK", f"{ip} is on the exclusion list"
    for net in IN_SCOPE:
        if ip in net:
            return "ALLOW", f"{ip} is inside {net}"
    return "BLOCK", f"{ip} is outside every approved CIDR"


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Check targets against Acme Phase 1 scope")
    p.add_argument("targets", nargs="?", help="Path to targets file")
    p.add_argument("--demo", action="store_true", help="Run built-in demonstration targets")
    p.add_argument("--emit", metavar="FILE", help="Week 3: write only ALLOWED targets to FILE (for nmap -iL)")
    p.add_argument("--add-scope", metavar="CIDR", action="append", default=[],
                   help="Week 3: approve your own isolated host-only lab subnet, e.g. 192.168.110.0/24 (repeatable)")
    p.add_argument("--exclude", metavar="IP", action="append", default=[],
                   help="Week 3: always refuse this IP, e.g. your host's vmnet adapter 192.168.110.1 (repeatable)")
    args = p.parse_args(argv)

    for c in args.add_scope:
        try:
            net = ipaddress.ip_network(c, strict=False)
        except ValueError:
            p.error(f"--add-scope {c!r} is not a valid CIDR")
        if not net.is_private or net.prefixlen < 16:
            p.error(f"--add-scope {c!r} refused: only private lab subnets of /16 or smaller are allowed")
        if net not in IN_SCOPE:
            IN_SCOPE.append(net)
    for x in args.exclude:
        try:
            EXCLUSIONS.add(ipaddress.ip_address(x))
        except ValueError:
            p.error(f"--exclude {x!r} is not a valid IPv4 address")

    if args.demo:
        lines = [
            "# demo targets for Week 2/3 lab",
            "192.168.56.101",
            "192.168.56.102",
            "192.168.56.1",
            "203.0.113.10",
            "203.0.113.200",
            "help.example",
            "8.8.8.8",
            "scanme.nmap.org",
            "127.0.0.1",
        ]
    else:
        if not args.targets:
            p.error("provide a targets file or --demo")
        lines = Path(args.targets).read_text(encoding="utf-8").splitlines()

    allowed = blocked = 0
    keep: list[str] = []
    print("scope_guard.py — Acme Project Phase 1 / Phase 2a")
    print("Approved:", ", ".join(str(n) for n in IN_SCOPE))
    print("-" * 60)
    for line in lines:
        status, reason = classify(line)
        if status == "skip":
            continue
        mark = "✓" if status == "ALLOW" else "✗"
        print(f"{mark} {status:5}  {line.strip():20}  {reason}")
        if status == "ALLOW":
            allowed += 1
            keep.append(line.strip())
        else:
            blocked += 1
    print("-" * 60)
    print(f"Summary: {allowed} allowed, {blocked} blocked")
    if args.emit:
        Path(args.emit).write_text("\n".join(keep) + "\n", encoding="utf-8")
        print(f"Wrote {len(keep)} allowed target(s) to {args.emit} (use: nmap -iL {args.emit} ...)")
    return 1 if blocked else 0


if __name__ == "__main__":
    sys.exit(main())
