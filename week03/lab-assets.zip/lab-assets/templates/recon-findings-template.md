# Acme Corp — Project Phase 2a recon notes (template)
Tester: ____________   Date/time (PT): ____________   RoE window confirmed: [ ] yes
Scope file used: nmap-targets.txt (from scope_guard.py)   Exclusions: <HOST-IP> (your VMware host-only adapter, usually .1)

## 1. Passive dossier (Keep / Verify / Out of scope)
| # | Finding | Source | Decision | Why |
|---|---|---|---|---|

## 2. Host discovery
Command:
Live hosts:

## 3. Port and service inventory (paste nmap_to_findings.py table)

## 4. Enumeration notes (NSE / DNS / SMB / SMTP / SNMP)
| Host:port | Command | Key output | Meaning |
|---|---|---|---|

## 5. Report-ready findings (five)
| ID | Title | Evidence (file + line) | Confidence | Severity (draft) | Next step |
|---|---|---|---|---|---|
