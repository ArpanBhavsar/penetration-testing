Week 4 lab assets — Penetration Testing · Focus College · Fall 2026
Unzip next to week4-lab.html so paths like lab-assets/cvss31.py resolve.

Student zip contains: scripts (cvss31.py, prioritize.py, scope_guard.py, acme_vuln_lab.py, vulners_summary.py),
templates, sample-output (format reference), data/kev-epss-snapshot.json (NVD+EPSS+KEV offline snapshot from 2026-10-22), this README.
Instructor zip adds solutions/ with verified transcripts.

Primary target: Metasploitable 2 on VMware Host-only (stands in for Acme acme-legacy).
Real CVEs on that target include CVE-2011-2523 (vsftpd), CVE-2007-2447 (Samba usermap), CVE-2012-1823 (PHP-CGI, on CISA KEV).
Fallback: python3 lab-assets/acme_vuln_lab.py (SAFE banners only, binds 127.0.0.1:8088).

Lecture bridges: Equifax/Struts CVE-2017-5638, Heartbleed CVE-2014-0160, Log4Shell CVE-2021-44228,
EternalBlue/WannaCry CVE-2017-0144, MOVEit CVE-2023-34362 — score them with cvss31.py; rank with prioritize.py.

Never scan college, workplace, classmates, or random Internet hosts.
