# Acme Corp — Phase 2b Scope & RoE (CO-A2)

Window: Fri Oct 23 class lab + Sat Oct 24 – Fri Oct 30 daily during daytime-to-evening hours Pacific Time as announced on the LMS calendar for Assignment 2.

Authorized active targets: Host-only Metasploitable 2 / DVWA; 127.0.0.1 mini lab; optional light scanme.nmap.org per instructor announcement.

Allowed: Greenbone CE unauthenticated Full and fast; nmap -sV --script "vuln and safe and not http-slowloris-check" after scope_guard --nse ALLOW; Nikto; searchsploit (lookup only); cvss31.py; curl verification.

Forbidden: exploit/intrusive/dos/brute NSE; Metasploit fire; credentialed scans without further CO; live scanning of documentation ranges; college/classmate/workplace hosts.

Stop conditions: target crash, unexpected BLOCK from scope_guard, unclear ownership, real PII — email abhavsar@focuscollege.ca same day.
