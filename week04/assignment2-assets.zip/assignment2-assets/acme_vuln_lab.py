#!/usr/bin/env python3
"""acme_vuln_lab.py - Week 4 safe mini target (Penetration Testing, Focus College).

A tiny, SAFE stand-in for Acme's legacy web server "acme-legacy", for students whose
laptop cannot run Metasploitable 2 (for example some Apple-silicon Macs). It only
LOOKS old: it serves a deliberately dated Server banner, a robots.txt that leaks a
/backup/ path, a cookie set without the HttpOnly/Secure flags, and no security
headers -- exactly the kind of low-hanging fruit a vulnerability scanner reports.
It contains NO real vulnerability: there is no backdoor, no command execution, no
file you can read off the disk. It binds to 127.0.0.1 only.

  python3 acme_vuln_lab.py                 # serves http://127.0.0.1:8088
  python3 acme_vuln_lab.py --port 8099     # pick another port

Leave it running in one terminal while you scan it from another:
  nmap -sV -p 8088 127.0.0.1
  nikto -h http://127.0.0.1:8088
Stop it with Ctrl-C.
"""
from __future__ import annotations
import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

SERVER_BANNER = "Apache/2.2.8 (Ubuntu) DAV/2"   # EOL banner on purpose (acme-legacy stand-in)

PORTAL = """<!doctype html><html><head><title>Acme Corp Staff Portal (lab)</title></head>
<body><h1>Acme Corp Staff Portal</h1>
<p>Internal use only. Lab stand-in for acme-legacy. Nothing here is real.</p>
<!-- TODO before go-live: remove /backup/, patch Apache, set security headers -->
<ul><li><a href="/login.php">Staff login</a></li><li><a href="/status">Server status</a></li></ul>
</body></html>"""

ROBOTS = "User-agent: *\nDisallow: /backup/\nDisallow: /admin/\nDisallow: /phpinfo.php\n"

LOGIN = """<!doctype html><html><head><title>Acme Staff Login</title></head>
<body><h1>Login</h1><form method="post" action="/login.php">
User <input name="u"> Pass <input name="p" type="password">
<button>Sign in</button></form></body></html>"""

class H(BaseHTTPRequestHandler):
    def version_string(self):
        return SERVER_BANNER

    def _send(self, code, body="", ctype="text/html", extra=None):
        data = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        # Deliberately weak: a session cookie with no HttpOnly / no Secure / no SameSite
        self.send_header("Set-Cookie", "SESSIONID=lab-demo-123; path=/")
        # Deliberately missing: X-Frame-Options, Content-Security-Policy, X-Content-Type-Options, HSTS
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(data)

    def do_GET(self):
        p = self.path.split("?", 1)[0]
        if p in ("/", "/index.html"):
            self._send(200, PORTAL)
        elif p == "/robots.txt":
            self._send(200, ROBOTS, "text/plain")
        elif p == "/login.php":
            self._send(200, LOGIN)
        elif p == "/status":
            self._send(200, "<h1>Server status</h1><pre>uptime: lab</pre>")
        elif p == "/phpinfo.php":
            # Looks like an exposed phpinfo page (classic Nikto/scanner finding). All fake.
            self._send(200, "<title>phpinfo()</title><h1>PHP Version 5.2.4-2ubuntu5 (lab fake)</h1>")
        else:
            self._send(404, "<h1>404 Not Found</h1>")

    def do_HEAD(self):
        self.do_GET()

    def do_POST(self):
        # Never authenticates anyone; just echoes a generic message.
        try:
            n = int(self.headers.get("Content-Length", 0))
            self.rfile.read(n)
        except Exception:
            pass
        self._send(200, "<h1>Login failed</h1><p>Lab target: credentials are never accepted.</p>")

    def log_message(self, fmt, *args):
        pass  # keep the console quiet

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8088)
    a = ap.parse_args()
    srv = ThreadingHTTPServer(("127.0.0.1", a.port), H)
    print(f"Acme mini vuln lab (SAFE) listening on http://127.0.0.1:{a.port}", flush=True)
    print("Banner: " + SERVER_BANNER + "  |  robots.txt leaks /backup/  |  weak cookie + missing security headers")
    print("Scan it from another terminal; Ctrl-C to stop.", flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")

if __name__ == "__main__":
    main()
