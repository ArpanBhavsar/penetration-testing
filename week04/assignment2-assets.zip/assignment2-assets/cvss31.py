#!/usr/bin/env python3
"""cvss31.py - Week 4 helper (Penetration Testing, Focus College).

CVSS v3.1 BASE score calculator that prints every step of the official FIRST
equations, so you can check a hand calculation line by line. Standard library only.

  python3 cvss31.py "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H"
  python3 cvss31.py AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N
  python3 cvss31.py --quiet "<vector>"

Always confirm with https://www.first.org/cvss/calculator/3.1
Spec: https://www.first.org/cvss/v3.1/specification-document (section 7 and Appendix A).
"""
import argparse, math, sys

AV = {"N": 0.85, "A": 0.62, "L": 0.55, "P": 0.2}
AC = {"L": 0.77, "H": 0.44}
PR_U = {"N": 0.85, "L": 0.62, "H": 0.27}
PR_C = {"N": 0.85, "L": 0.68, "H": 0.50}
UI = {"N": 0.85, "R": 0.62}
CIA = {"H": 0.56, "L": 0.22, "N": 0.0}
NAMES = ("AV", "AC", "PR", "UI", "S", "C", "I", "A")

def roundup(x):
    i = round(x * 100000)
    return i / 100000.0 if i % 10000 == 0 else (math.floor(i / 10000) + 1) / 10.0

def severity(s):
    return "None" if s == 0 else "Low" if s < 4 else "Medium" if s < 7 else "High" if s < 9 else "Critical"

def parse(vector):
    v = vector.strip().replace("CVSS:3.1/", "").replace("CVSS:3.0/", "")
    m = dict(kv.split(":") for kv in v.split("/"))
    for k in NAMES:
        if k not in m:
            raise ValueError(f"vector is missing {k}")
    return m

def score(m):
    changed = m["S"] == "C"
    iss = 1 - (1 - CIA[m["C"]]) * (1 - CIA[m["I"]]) * (1 - CIA[m["A"]])
    impact = 7.52 * (iss - 0.029) - 3.25 * (iss - 0.02) ** 15 if changed else 6.42 * iss
    pr = (PR_C if changed else PR_U)[m["PR"]]
    expl = 8.22 * AV[m["AV"]] * AC[m["AC"]] * pr * UI[m["UI"]]
    if impact <= 0:
        base = 0.0
    else:
        base = roundup(min((1.08 if changed else 1) * (impact + expl), 10))
    return dict(iss=iss, impact=impact, expl=expl, pr=pr, base=base, changed=changed)

def explain(vector):
    m = parse(vector)
    r = score(m)
    c, i, a = CIA[m["C"]], CIA[m["I"]], CIA[m["A"]]
    print(f"Vector: CVSS:3.1/{'/'.join(f'{k}:{m[k]}' for k in NAMES)}")
    print("Step 1  ISS = 1 - (1-C)(1-I)(1-A)")
    print(f"        = 1 - (1-{c})(1-{i})(1-{a}) = 1 - {(1-c)*(1-i)*(1-a):.6f} = {r['iss']:.4f}")
    if r["changed"]:
        print("Step 2  Scope CHANGED: Impact = 7.52 x (ISS - 0.029) - 3.25 x (ISS - 0.02)^15")
        print(f"        = 7.52 x {r['iss'] - 0.029:.4f} - 3.25 x {(r['iss'] - 0.02):.4f}^15 = {r['impact']:.4f}")
    else:
        print("Step 2  Scope UNCHANGED: Impact = 6.42 x ISS")
        print(f"        = 6.42 x {r['iss']:.4f} = {r['impact']:.4f}")
    print("Step 3  Exploitability = 8.22 x AV x AC x PR x UI")
    print(f"        = 8.22 x {AV[m['AV']]} x {AC[m['AC']]} x {r['pr']} x {UI[m['UI']]} = {r['expl']:.4f}")
    if r["impact"] <= 0:
        print("Step 4  Impact <= 0, so Base = 0.0")
    elif r["changed"]:
        tot = 1.08 * (r["impact"] + r["expl"])
        print(f"Step 4  Base = Roundup(min(1.08 x (Impact + Exploitability), 10)) = Roundup(min({tot:.4f}, 10)) = {r['base']}")
    else:
        tot = r["impact"] + r["expl"]
        print(f"Step 4  Base = Roundup(min(Impact + Exploitability, 10)) = Roundup(min({tot:.4f}, 10)) = {r['base']}")
    print(f"Result  {r['base']} ({severity(r['base'])})")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("vector")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()
    try:
        if a.quiet:
            r = score(parse(a.vector))
            print(r["base"], severity(r["base"]))
        else:
            explain(a.vector)
    except (ValueError, KeyError) as e:
        sys.exit(f"Bad vector: {e}")
