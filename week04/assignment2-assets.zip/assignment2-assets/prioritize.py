#!/usr/bin/env python3
"""Week 4 helper: rank CVEs by the signals we teach (KEV first, then EPSS, then CVSS).
Reads lab-assets/data/kev-epss-snapshot.json (offline snapshot of NVD + FIRST EPSS + CISA KEV).
usage: python3 lab-assets/prioritize.py CVE-2017-5638 CVE-2014-0160 ...   (or --all)
Add --reach CVE=internet|vpn|lab to record reachability; internet-facing rows break ties first.
This is a teaching aid, not a risk model: asset value and reachability still need your judgment."""
import json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
SNAP = json.load(open(os.path.join(HERE, "data", "kev-epss-snapshot.json")))
REACH_W = {"internet": 2, "vpn": 1, "lab": 0}

def main(argv):
    reach = {}
    ids = []
    it = iter(argv)
    for a in it:
        if a == "--reach":
            k, v = next(it).split("="); reach[k.upper()] = v
        elif a == "--all":
            ids = sorted(SNAP["cves"])
        else:
            ids.append(a.upper())
    if not ids:
        print(__doc__); return 1
    rows = []
    for c in ids:
        d = SNAP["cves"].get(c)
        if not d:
            print(f"{c}: not in offline snapshot - look it up live on nvd.nist.gov, first.org/epss and cisa.gov/kev"); continue
        cv = d.get("v31_score")
        rows.append((c, bool(d.get("kev")), d.get("epss") or 0.0, cv if cv is not None else -1, d.get("v2_score"), d.get("kev_date_added"), d.get("kev_ransomware"), reach.get(c, "lab")))
    rows.sort(key=lambda r: (not r[1], -REACH_W.get(r[7], 0), -r[2], -r[3]))
    print(SNAP["_note"])
    print(f"{'#':>2}  {'CVE':<15} {'KEV':<11} {'Ransom':<8} {'EPSS':>7}  {'CVSS3.1':>7}  {'v2':>4}  Reach")
    for n, (c, k, e, s, v2, kd, rw, rc) in enumerate(rows, 1):
        s_txt = f"{s:.1f}" if s >= 0 else "none"
        print(f"{n:>2}  {c:<15} {(kd or 'no'):<11} {(rw or '-'):<8} {e:>7.5f}  {s_txt:>7}  {str(v2 or '-'):>4}  {rc}")
    print("Order rule: KEV listed > reachable from internet > higher EPSS > higher CVSS. 'none' = NVD has no v3.1 score; compute and label your own.")
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
