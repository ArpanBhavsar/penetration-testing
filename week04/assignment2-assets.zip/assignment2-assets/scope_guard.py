#!/usr/bin/env python3
"""scope_guard.py — Week 2 helper, extended for Week 3 and Week 4 (Penetration Testing, Focus College).

Refuse to proceed when a proposed target is outside the approved CIDR ranges
or appears on the exclusion list. Reuse this before Nmap in Week 3.

Usage:
  python3 scope_guard.py targets.txt
  python3 scope_guard.py targets.txt --emit nmap-targets.txt   # Week 3: write ALLOWED lines for nmap -iL
  python3 scope_guard.py --demo
  python3 scope_guard.py targets.txt --add-scope 192.168.110.0/24 --exclude 192.168.110.1 --emit nmap-targets.txt
      # Week 3 (VMware): approve YOUR host-only subnet and exclude your host's own adapter IP.
      # --add-scope and --exclude may be repeated. Only ever add an isolated host-only lab subnet.
  python3 scope_guard.py --nse "vuln"
  python3 scope_guard.py --nse "vuln and safe and not http-slowloris-check"
      # Week 4 (Phase 2b): before any NSE vulnerability scan, list exactly which scripts an
      # expression selects and BLOCK the run if any of them is in a category the Phase 2b RoE
      # forbids (exploit, intrusive, dos, brute). Reads Nmap's own script.db.

The targets file contains one IPv4 address or host label per line.
Lines starting with # are comments.
"""
from __future__ import annotations

import argparse
import ipaddress
import sys
from pathlib import Path

# Acme Project Phase 1 approved ranges (lab + documentation examples)
IN_SCOPE = [
    ipaddress.ip_network("192.168.56.0/24"),  # course host-only lab
    ipaddress.ip_network("203.0.113.0/25"),   # Acme public half (docs range; never scanned live)
    ipaddress.ip_network("127.0.0.0/8"),      # Week 3: your own machine (acme_mini_lab.py)
]

# Week 3: hostnames whose owners explicitly permit light practice scanning
ALLOWED_LABELS = {
    "scanme.nmap.org",       # Nmap project's practice host: light scans only, a few times a day
    "localhost",
}

# Always refuse these even if they fall inside a wide CIDR
EXCLUSIONS = {
    ipaddress.ip_address("192.168.56.1"),     # VirtualBox host gateway (your laptop)
    ipaddress.ip_address("203.0.113.1"),      # reserved example gateway
}

# Labels that are never in scope for Phase 1 without a change order
BLOCKED_LABELS = {
    "help.example",          # SaaS help desk — vendor permission required
    "college.lms.example",   # college systems
}


def classify(token: str) -> tuple[str, str]:
    token = token.strip()
    if not token or token.startswith("#"):
        return "skip", "comment or empty"
    lower = token.lower()
    if lower in BLOCKED_LABELS:
        return "BLOCK", f"label '{token}' is excluded (third-party or college)"
    if lower in ALLOWED_LABELS:
        return "ALLOW", f"label '{token}' is an explicitly permitted practice target"
    try:
        ip = ipaddress.ip_address(token)
    except ValueError:
        return "BLOCK", f"'{token}' is not a bare IPv4 address; resolve and re-check"
    if ip in EXCLUSIONS:
        return "BLOCK", f"{ip} is on the exclusion list"
    for net in IN_SCOPE:
        if ip in net:
            return "ALLOW", f"{ip} is inside {net}"
    return "BLOCK", f"{ip} is outside every approved CIDR"


# Week 4 (Phase 2b, change order CO-A2): NSE categories the RoE forbids during vulnerability scanning.
# exploit = actually attacks the target (that is Week 5+); intrusive / dos = can crash, slow or change it;
# brute = password guessing. ("malware" scripts only CHECK for an existing backdoor; they are blocked only when
# they also carry one of these categories, e.g. ftp-vsftpd-backdoor is exploit + intrusive.)
FORBIDDEN_NSE = {"exploit", "intrusive", "dos", "brute"}
SCRIPT_DB_PATHS = ["/usr/share/nmap/scripts/script.db", "/usr/local/share/nmap/scripts/script.db",
                   "/opt/homebrew/share/nmap/scripts/script.db", r"C:\Program Files (x86)\Nmap\scripts\script.db"]


def load_script_db(path: str | None = None) -> dict[str, set[str]]:
    """Return {script name: {categories}} from Nmap's script.db (one Entry per line)."""
    import re
    for cand in ([path] if path else SCRIPT_DB_PATHS):
        if cand and Path(cand).exists():
            db = {}
            for line in Path(cand).read_text(encoding="utf-8", errors="replace").splitlines():
                m = re.match(r'Entry \{ filename = "([^"]+)\.nse", categories = \{ (.*) \} \}', line.strip())
                if m:
                    db[m.group(1)] = set(re.findall(r'"([^"]+)"', m.group(2)))
            return db
    raise SystemExit("script.db not found: pass --script-db /path/to/nmap/scripts/script.db")


def nse_select(expr: str, db: dict[str, set[str]]) -> list[str]:
    """Evaluate an Nmap --script expression (and / or / not / parentheses / commas / * wildcards)
    over categories and script names, the way Nmap does, and return the selected script names."""
    import fnmatch, re
    toks = re.findall(r"\(|\)|,|[^\s(),]+", expr)
    def ev(name: str, cats: set[str]) -> bool:
        pos = 0
        def atom():
            nonlocal pos
            t = toks[pos]; pos += 1
            if t == "(":
                v = orx()
                pos += 1          # skip ")"
                return v
            if t == "not":
                return not atom()
            t = t[:-4] if t.endswith(".nse") else t
            return t in cats or t == "all" or fnmatch.fnmatch(name, t)
        def andx():
            nonlocal pos
            v = atom()
            while pos < len(toks) and toks[pos] == "and":
                pos += 1; v = atom() and v
            return v
        def orx():
            nonlocal pos
            v = andx()
            while pos < len(toks) and toks[pos] in ("or", ","):
                pos += 1; v = andx() or v
            return v
        return orx()
    return sorted(n for n, c in db.items() if ev(n, c))


def nse_check(expr: str, db_path: str | None = None) -> int:
    db = load_script_db(db_path)
    sel = nse_select(expr, db)
    print("scope_guard.py — Acme Project Phase 2b NSE policy check (CO-A2)")
    print(f"Expression: {expr!r}  ->  {len(sel)} script(s) selected")
    print("Forbidden categories:", ", ".join(sorted(FORBIDDEN_NSE)))
    print("-" * 60)
    bad = 0
    for n in sel:
        hit = sorted(db[n] & FORBIDDEN_NSE)
        if hit:
            bad += 1
            print(f"✗ BLOCK  {n:32}  categories: {', '.join(sorted(db[n]))}")
    print("-" * 60)
    if bad:
        print(f"Summary: {bad} of {len(sel)} selected scripts are forbidden by the Phase 2b RoE. Do NOT run this expression.")
        return 1
    for n in sel:
        print(f"✓ ALLOW  {n:32}  categories: {', '.join(sorted(db[n]))}")
    print(f"Summary: all {len(sel)} selected scripts are allowed. OK to run against in-scope lab targets.")
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Check targets against Acme Phase 1 scope")
    p.add_argument("targets", nargs="?", help="Path to targets file")
    p.add_argument("--demo", action="store_true", help="Run built-in demonstration targets")
    p.add_argument("--emit", metavar="FILE", help="Week 3: write only ALLOWED targets to FILE (for nmap -iL)")
    p.add_argument("--add-scope", metavar="CIDR", action="append", default=[],
                   help="Week 3: approve your own isolated host-only lab subnet, e.g. 192.168.110.0/24 (repeatable)")
    p.add_argument("--exclude", metavar="IP", action="append", default=[],
                   help="Week 3: always refuse this IP, e.g. your host's vmnet adapter 192.168.110.1 (repeatable)")
    p.add_argument("--nse", metavar="EXPR", help="Week 4: check an Nmap --script expression against the Phase 2b RoE")
    p.add_argument("--script-db", metavar="PATH", help="Week 4: path to Nmap's scripts/script.db if not in a standard place")
    args = p.parse_args(argv)
    if args.nse:
        return nse_check(args.nse, args.script_db)

    for c in args.add_scope:
        try:
            net = ipaddress.ip_network(c, strict=False)
        except ValueError:
            p.error(f"--add-scope {c!r} is not a valid CIDR")
        if not net.is_private or net.prefixlen < 16:
            p.error(f"--add-scope {c!r} refused: only private lab subnets of /16 or smaller are allowed")
        if net not in IN_SCOPE:
            IN_SCOPE.append(net)
    for x in args.exclude:
        try:
            EXCLUSIONS.add(ipaddress.ip_address(x))
        except ValueError:
            p.error(f"--exclude {x!r} is not a valid IPv4 address")

    if args.demo:
        lines = [
            "# demo targets for Week 2/3 lab",
            "192.168.56.101",
            "192.168.56.102",
            "192.168.56.1",
            "203.0.113.10",
            "203.0.113.200",
            "help.example",
            "8.8.8.8",
            "scanme.nmap.org",
            "127.0.0.1",
        ]
    else:
        if not args.targets:
            p.error("provide a targets file or --demo")
        lines = Path(args.targets).read_text(encoding="utf-8").splitlines()

    allowed = blocked = 0
    keep: list[str] = []
    print("scope_guard.py — Acme Project Phase 1 / Phase 2a / Phase 2b")
    print("Approved:", ", ".join(str(n) for n in IN_SCOPE))
    print("-" * 60)
    for line in lines:
        status, reason = classify(line)
        if status == "skip":
            continue
        mark = "✓" if status == "ALLOW" else "✗"
        print(f"{mark} {status:5}  {line.strip():20}  {reason}")
        if status == "ALLOW":
            allowed += 1
            keep.append(line.strip())
        else:
            blocked += 1
    print("-" * 60)
    print(f"Summary: {allowed} allowed, {blocked} blocked")
    if args.emit:
        Path(args.emit).write_text("\n".join(keep) + "\n", encoding="utf-8")
        print(f"Wrote {len(keep)} allowed target(s) to {args.emit} (use: nmap -iL {args.emit} ...)")
    return 1 if blocked else 0


if __name__ == "__main__":
    sys.exit(main())
