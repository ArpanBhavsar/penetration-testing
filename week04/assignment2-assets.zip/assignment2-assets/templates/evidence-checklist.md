# A2 evidence checklist

- [ ] scope_guard IP transcript
- [ ] scope_guard --nse ALLOW transcript
- [ ] Nmap -oA set and/or Greenbone export
- [ ] Nikto output
- [ ] searchsploit excerpts (≥2)
- [ ] cvss31 / FIRST workings for each Keep
- [ ] FP disproof (curl or second tool)
- [ ] findings draft table
