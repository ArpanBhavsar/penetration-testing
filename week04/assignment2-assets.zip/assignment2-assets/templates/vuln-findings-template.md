# Acme Corp — Phase 2b vulnerability findings (draft)

Engagement: Acme Corp · Tester: ________ · Date (PT): ________
Target path: [ ] Metasploitable 2 host-only   [ ] mini lab 127.0.0.1:8088

## Keep findings

| ID | Title | Asset:port | Evidence path | CVSS v3.1 vector | Score | Confidence | Business meaning | Next step |
|----|-------|------------|---------------|------------------|-------|------------|------------------|-----------|
| V-01 | | | | | | | | |
| V-02 | | | | | | | | |
| V-03 | | | | | | | | |
| V-04 | | | | | | | | |
| V-05 | | | | | | | | |

## False positives / discarded

| ID | Tool said | Why discarded | Evidence path |
|----|-----------|---------------|---------------|
| FP-01 | | | |

## Notes
- scope_guard --nse expression used: `vuln and safe and not http-slowloris-check`
- Greenbone task name (if any):
- EPSS/KEV checks performed on:
