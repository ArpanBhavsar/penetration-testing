#!/usr/bin/env python3
"""Summarise the vulners NSE table from an Nmap XML (-oX / -oA) into a short triage list.
Keeps only CVE-* rows, sorts by CVSS descending, prints top N. Standard library only.

  python3 vulners_summary.py sample-output/mini-vuln-safe.xml --top 10
"""
import argparse, xml.etree.ElementTree as ET
ap = argparse.ArgumentParser(); ap.add_argument("xml"); ap.add_argument("--top", type=int, default=10)
a = ap.parse_args()
rows = []
for script in ET.parse(a.xml).getroot().iter("script"):
    if script.get("id") != "vulners": continue
    for table in script.findall("table"):
        cpe = table.get("key", "")
        for row in table.findall("table"):
            d = {e.get("key"): e.text for e in row.findall("elem")}
            if not (d.get("id") or "").startswith("CVE-"): continue
            try: cvss = float(d.get("cvss") or 0)
            except ValueError: cvss = 0.0
            rows.append((cvss, d.get("id"), cpe, d.get("is_exploit") == "true"))
rows.sort(reverse=True)
print(f"{'CVSS':>5}  {'CVE':<16}  exploit  CPE")
for cvss, cve, cpe, exp in rows[:a.top]:
    print(f"{cvss:5.1f}  {cve:<16}  {'yes' if exp else 'no ':3}     {cpe}")
print(f"({len(rows)} CVE rows total; showing top {min(a.top, len(rows))}. Banner-matched — verify before reporting.)")
