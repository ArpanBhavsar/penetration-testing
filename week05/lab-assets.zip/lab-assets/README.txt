Penetration Testing — Week 5 Lab Assets (Attacks & Exploits I)
Focus College · Fall 2026 · Instructor: Arpan Bhavsar · Client: Acme Corp (fictional)

HOW TO USE
  Unzip this so that a folder named lab-assets/ sits next to week5-lab.html,
  so paths like lab-assets/shadow.txt resolve from the workbook.

PRIMARY TARGET
  Live Metasploitable 2 ("acme-legacy") with a Kali attacker on a HOST-ONLY
  network, never bridged. Everything else here is a clearly-labelled FALLBACK
  for students with no VM (e.g. Apple-silicon). Your Phase 3a evidence must come
  from your own runs where possible; say so if you used a fallback.

FILES
  shadow.txt              Captured md5crypt ($1$) hashes (fallback for Part C). Crack with John / Hashcat -m 500.
  wpa2-handshake.cap      Raw WPA2 4-way handshake capture (SSID AcmeStore) for Part D. Convert with hcxpcapngtool.
  wpa2.hc22000            Pre-converted WPA2 hash, ready for: hashcat -m 22000 wpa2.hc22000 wifi-wordlist.txt
  wifi-wordlist.txt       Small lab wordlist (contains the weak lab key) for Part D.
  sample-output/          Verified / representative tool transcripts (fallback reading):
                            vsftpd-exploit.txt, samba-exploit.txt, smb-version.txt,
                            smb-enumshares.txt, responder-ntlmrelayx.txt
  templates/              phase3a-evidence-template.md  (fill this in for the project)
  solutions/              (INSTRUCTOR zip only) worked answers + recovered values

ETHICS
  Host-only / lab targets only. Never college, workplace, classmates, or any
  real network or Wi-Fi. Authorization (Week 2 scope) is what makes this legal.

VERIFIED
  wpa2.hc22000 was self-verified: PBKDF2/PRF/MIC math recovers "AcmeStore2023".
  shadow.txt hashes were verified crackable (all six accounts). Captured 2026-10-28.
