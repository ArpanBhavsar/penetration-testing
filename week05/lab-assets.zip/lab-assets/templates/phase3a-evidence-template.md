# Project Phase 3a — Evidence Pack (student template)

**Tester:** __________    **Date/time (PT):** __________
**Authorization:** Week 2 scope + authorization letter; target = acme-legacy (host-only).

## 1. Exploitation
- Module path: __________
- Options set (RHOSTS/PAYLOAD/LHOST): __________
- Result / session: __________
- [ ] Proof-of-access screenshot attached (id = uid=0, hostname, timestamp)

## 2. Hashes captured
- Source file on host: /etc/shadow
- Saved as: __________  (format prefix: $__$)

## 3. Cracking
- Tool: [ ] John  [ ] Hashcat    Mode (if Hashcat -m): ______
- Wordlist: __________
- Cracked credential(s): __________

## 4. Conduct
- [ ] Stayed in scope    [ ] No destructive actions    [ ] All steps logged
- Fallback used? (state which parts, if any): __________
