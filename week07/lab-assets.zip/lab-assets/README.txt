Penetration Testing Week 7 — lab-assets
Unzip beside week7-lab.html so paths like lab-assets/templates/... resolve.

Contents:
  sample-output/     Fallback transcripts (use ONLY if Metasploitable 2 is unavailable)
  templates/         Phase 3b evidence worksheet + Assignment 3 brief
  vulnerable-code/   Teaching snippets for the "reading vulnerable code" exercise
  solutions/         Instructor pack only (answers) — omitted from student zip

Primary target: Metasploitable 2 at 192.168.1.200
  DVWA:       http://192.168.1.200/dvwa/   (admin / password)
  Mutillidae: http://192.168.1.200/mutillidae/
Optional: OWASP Juice Shop via Docker on Kali (see lab workbook).
