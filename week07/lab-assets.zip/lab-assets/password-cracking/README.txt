Password cracking — lab-assets (Week 7, Part 0b; authentication-attacks carry-over from Week 5)
Unzip beside week7-lab.html so lab-assets/password-cracking/... paths resolve.

PRIMARY PATH (do this): crack hashes you pull from the LIVE target, Metasploitable 2 at
192.168.1.200, after getting root in the Week 5 exploitation. See crack-commands.sh.

FALLBACK ONLY (use ONLY if the VM is unavailable):
  sample-passwd.txt        fallback /etc/passwd copy (NOT from a live host)
  sample-shadow.txt        fallback /etc/shadow copy with md5crypt ($1$) hashes
  sample-john-output.txt   fallback transcript of the expected john run + john --show
  pw-small.txt             tiny controlled wordlist for the hydra (online) demo
These canned files are illustrative. They are NOT a substitute for cracking the live host.

Known-weak Metasploitable 2 accounts used here: msfadmin/msfadmin, user/user,
service/service, postgres/postgres, sys/batman. root and klog use strong passwords and
are expected to remain uncracked (that is why john reports "2 left").

Free tools only (all on Kali): John the Ripper (jumbo), Hashcat, hydra, rockyou.txt.
