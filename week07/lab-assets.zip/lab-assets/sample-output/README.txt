FALLBACK ONLY — use these transcripts if Metasploitable 2 / DVWA is unavailable.
They are not a substitute for live work when the lab is up.
