# Assignment 3 — Web Application Penetration Test (6%)
Course: Penetration Testing · Focus College · Instructor: Arpan Bhavsar
Issued: Friday, November 13, 2026 · Due: Friday, November 20, 2026, 11:59 pm PT

## Objective
Perform an authorized web application penetration test against Acme Corp's lab web apps and deliver a consultant-style report with reproducible evidence and remediation guidance.

## Authorized scope
- Host-only Metasploitable 2 at 192.168.1.200
- DVWA (`/dvwa/`) and Mutillidae on that host
- Optional: OWASP Juice Shop on Kali via Docker (`http://127.0.0.1:3000`) if you choose it — document which target you used
- Tools: Burp Suite Community, OWASP ZAP, sqlmap, browser DevTools
- Out of scope: any production URL, college network, third-party sites, classmates' systems without written consent

## Required findings
At least **three** distinct OWASP Top 10:2021 categories, including:
1. SQL injection (A03), and
2. Either XSS (A07) **or** broken access control / IDOR (A01), and
3. One additional distinct category (command injection, CSRF, SSRF, file inclusion/upload, misconfiguration, etc.)

Each finding must include: OWASP mapping, steps to reproduce, request/response (or annotated screenshot), business impact for Acme, and developer-actionable remediation.

## Deliverable
One PDF or DOCX report, 4–6 pages plus appendix:
1. Executive summary (non-technical, Acme-facing)
2. Findings table (title, OWASP, severity, status)
3. Detailed write-ups (one section each)
4. Remediation roadmap (prioritized)
5. Appendix: evidence (redact secrets)

## Grading emphasis (100 pts)
- Vulnerability discovery & OWASP coverage — 25
- Evidence quality (minimum proof, reproducible) — 25
- Tool proficiency & methodology notes — 15
- Engagement tone / RoE discipline — 15
- Remediation quality — 15
- Clarity / professionalism — 5

## Academic integrity
Do not attack systems outside the authorized lab. Do not submit another student's evidence. Cite tool versions you used.
