# Phase 3b — Web Finding Evidence Worksheet
Client: Acme Corp (authorized lab) · Tester: ________ · Date (PT): ________

## Finding title
(short, specific)

## OWASP Top 10:2021 mapping
- [ ] A01 Broken Access Control (incl. IDOR)
- [ ] A03 Injection (SQLi / command)
- [ ] A07 XSS
- [ ] Other: ________

## Affected URL and parameter
URL:
Parameter(s):
Auth state (anonymous / user / admin):

## Steps to reproduce
1.
2.
3.

## Evidence
Paste request (redact session secrets if uploading to LMS):

```
(request)
```

Paste or describe response / attach screenshot filename:

```
(response)
```

## Business impact (one paragraph for Acme)
Who can do what to whose data? What is the operational or privacy cost?

## Remediation (developer-actionable)
Root cause:
Fix guidance:
Retest idea:

## Severity (justify in plain language)
Rating: Informational / Low / Medium / High / Critical
Why:

## Cleanup performed
- [ ] Stored payloads removed
- [ ] Test accounts noted
- [ ] No dumps retained beyond RoE
