vulnerable-code/ — short PHP teaching snippets for Week 7 "reading vulnerable code".
These are NOT deployed services. Read them beside your Burp proof to name the root cause.
Pair: sqli_concat.php ↔ sqli_fixed.php ; xss_echo.php ↔ xss_fixed.php ; cmd_concat.php (fix = avoid shell / allowlist).
