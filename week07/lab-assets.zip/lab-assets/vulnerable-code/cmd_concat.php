<?php
// Teaching snippet — command injection anti-pattern.
$host = $_GET["ip"];
// Dangerous: passes user input to a shell.
system("ping -c 1 " . $host);
