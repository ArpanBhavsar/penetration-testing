<?php
// Teaching snippet — intentionally vulnerable (DO NOT deploy).
// Mirrors the anti-pattern behind many DVWA-style SQLi labs.
$conn = mysqli_connect("127.0.0.1", "app", "app", "acme");
$id = $_GET["id"];  // untrusted
$query = "SELECT first_name, last_name FROM users WHERE user_id = '$id';";
$result = mysqli_query($conn, $query);
while ($row = mysqli_fetch_assoc($result)) {
    echo $row["first_name"] . " " . $row["last_name"] . "<br>";
}
