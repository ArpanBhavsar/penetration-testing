<?php
// Teaching snippet — parameterized fix idea (mysqli).
$conn = mysqli_connect("127.0.0.1", "app", "app", "acme");
$id = $_GET["id"];
$stmt = mysqli_prepare($conn, "SELECT first_name, last_name FROM users WHERE user_id = ?");
mysqli_stmt_bind_param($stmt, "s", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
while ($row = mysqli_fetch_assoc($result)) {
    echo htmlspecialchars($row["first_name"] . " " . $row["last_name"], ENT_QUOTES, "UTF-8") . "<br>";
}
