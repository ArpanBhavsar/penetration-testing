<?php
// Teaching snippet — reflected XSS anti-pattern.
$name = $_GET["name"];
echo "<h1>Hello, $name</h1>";  // unencoded output into HTML
