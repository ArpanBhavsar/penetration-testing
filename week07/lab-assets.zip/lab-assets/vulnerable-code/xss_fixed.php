<?php
// Teaching snippet — output encoding fix idea.
$name = $_GET["name"] ?? "";
echo "<h1>Hello, " . htmlspecialchars($name, ENT_QUOTES, "UTF-8") . "</h1>";
